const currency_1 = document.getElementById('source-currency');
const currency_2 = document.getElementById('target-currency');
const source_currency=document.getElementById('source-currency');
const target_currency=document.getElementById('target-currency');
const input = document.getElementById('number');
const exchange_button = document.getElementById('convert');
const result = document.getElementById('result'); 


function populateCurrencies() {
    fetch('https://restcountries.com/v3.1/all')
        .then(response => response.json())
        .then(countries => {
            const currencies = {};
            countries.forEach(country => {
                const currencyCode = Object.keys(country.currencies || {})[0];
                const currencyName = country.currencies[currencyCode]?.name || currencyCode;
                const countryName = country.name.common;

                if (currencyCode && !currencies[currencyCode]) {
                    currencies[currencyCode] = currencyName;
                    const option1 = document.createElement('option');
                    option1.value = currencyCode;
                    option1.textContent = ${currencyName} (${currencyCode});
                    source_currency.appendChild(option1);

                    const option2 = document.createElement('option');
                    option2.value = currencyCode;
                    option2.textContent = ${currencyName} (${currencyCode});
                    target_currency.appendChild(option2);
                }
            });
        })
        .catch(err => {
            console.error(err);
            alert('Error fetching country data.');
        });
}


function cal() {
    const currency_one = currency_1.value;
    const currency_two = currency_2.value;
    const amount = parseFloat(input.value); 

    if (isNaN(amount)) {
        result.innerText = "Please enter a valid number.";
        return;
    }

    fetch(`https://v6.exchangerate-api.com/v6/277d52e4dd82f06a4c34cd5a/latest/${currency_one}`)
        .then(res => res.json())
        .then(data => {
            const rate = data.conversion_rates[currency_two];
            result.innerText = `1 ${currency_one} = ${rate} ${currency_two}`;
            const convertedAmount = (amount * rate).toFixed(2);
            result.innerText = `${amount} ${currency_one} = ${convertedAmount} ${currency_two}`; // Displaying the result
        })
        .catch(err => {
            console.error(err);
            result.innerText = "Error fetching exchange rates.";
        });
}
populateCurrencies();

exchange_button.addEventListener('click', cal);
